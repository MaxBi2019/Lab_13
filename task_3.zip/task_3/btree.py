"""
Module with GameTree class
"""
from random import randint
from binary_search_tree.linkedbst import LinkedBST
from binary_search_tree.bstnode import BSTNode


class GameTree:
    """
    Represent Tree for making decisions
    """
    def __init__(self, board):
        """
        :param board: Board
        -------------------
        Initialize Board object
        """
        self._tree = LinkedBST()
        self._tree.add(board)

    def __generate(self):
        """
        :return: Board, Board
        ---------------------
        Generate possible outcomes
        and return two pivot boards
        """
        def play(lst, board, exclude=None):
            """
            :param lst: list
            :param board: Board
            :param exclude: None or tuple
            :return: Board, tuple
            ---------------------
            Make random moves
            """
            if exclude:
                tem = [elm for elm in lst if elm != exclude]
                pos_1 = tem.pop(randint(0, len(tem)-1))
                lst.remove(pos_1)
            else:
                pos_1 = lst.pop(randint(0, len(lst)-1))
            pos_2 = lst.pop(randint(0, len(lst)-1))
            board[pos_1] = 0
            if not board.is_over():
                board[pos_2] = 1
            return board, pos_1

        def builder(root_, lst):
            """
            :param root_: BSTNode
            :param lst: list
            :return: None
            -------------
            Generate new outcomes as long as possible
            """
            lst_r = lst[:]
            lst_l = lst[:]
            if lst_r:
                board = root_.data.copy()
                board, pos = play(lst_r, board)
                root_.right = BSTNode(board)
                if not board.is_over():
                    builder(root_.right, lst_r)
            if lst_l:
                board = root_.data.copy()
                board, pos = play(lst_l, board, exclude=pos)
                root_.left = BSTNode(board)
                if not board.is_over():
                    builder(root_.left, lst_l)

        root = self._tree.tree_root
        cells = root.data.free_cells()
        lst_t = cells[:]
        lft, rgt = root.data.copy(), root.data.copy()
        lft[lst_t.pop(randint(0, len(lst_t)-1))] = 0
        rgt[lst_t.pop(randint(0, len(lst_t)-1))] = 0
        board_lft = lft.copy()
        board_rgt = rgt.copy()
        lst_rg, lst_lf = lft.free_cells(), rgt.free_cells()
        lft[lst_rg.pop(randint(0, len(lst_rg)-1))] = 1
        rgt[lst_lf.pop(randint(0, len(lst_lf)-1))] = 1
        root.left = BSTNode(lft)
        root.right = BSTNode(rgt)
        builder(root.right, lst_rg)
        builder(root.left, lst_lf)
        return board_lft, board_rgt

    def decide(self):
        """
        :return: Board
        --------------
        Returns the best move decision
        """
        left, right = self.__generate()
        if left.is_over()[0] or right.is_over()[0]:
            return right if right.is_over()[0] else left
        left_tree = LinkedBST()
        left_tree.tree_root = self._tree.tree_root.left
        right_tree = LinkedBST()
        right_tree.tree_root = self._tree.tree_root.right
        res = "right" if sum(map(lambda arg: arg.value(), left_tree)) < sum(
            map(lambda arg: arg.value(), right_tree)) else "left"
        return left if res == "left" else right
