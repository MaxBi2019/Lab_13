"""
Game module
"""

from btree import GameTree
from board import Board


def inp_checker(cells):
    """
    :param cells:
    :return: tuple
    --------------
    Check for correct input
    """
    msg_1 = "Please, enter two integers separated with SPACE"
    try:
        inp = tuple(map(int, input("Make your move: ").split()))
    except (ValueError, IndexError):
        print(msg_1)
        return inp_checker(cells)
    if len(inp) != 2:
        print(msg_1)
    if inp in cells:
        return inp
    n_l = "\n"
    print(f"You can choose only: \n{n_l.join([str(elm[0]) + ' ' + str(elm[1]) for elm in cells])}")
    return inp_checker(cells)


def main():
    """
    Run a Game
    """
    board = Board()
    while True:
        print(board, "\n")
        first_step = inp_checker(board.free_cells())
        board[(first_step)] = 1
        if board.is_over()[0]:
            break
        board = GameTree(board).decide()
        if board.is_over()[0]:
            break
    print("GAME OVER")
    print(board, "\n")
    print(f"{({0:'computer', 1:'user'}[board.is_over()[1]]).capitalize()} won!!!")


if __name__ == "__main__":
    main()
