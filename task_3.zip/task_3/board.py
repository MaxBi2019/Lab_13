"""
Module with Board class
"""
from ctypes import py_object
SIZE = 3


class TripleArray:
    """
    Represent 3-slot array
    """
    def __init__(self, fill=None):
        """
        :param fill: None or str
        ------------------------
        Initialize array object
        """
        self._cells = (py_object*SIZE)()
        for ind in range(SIZE):
            if fill == "array":
                self._cells[ind] = TripleArray()
            else:
                self._cells[ind] = None

    def __getitem__(self, ind):
        """
        :param ind: int
        :return: any
        ------------
        Return value on ind-th slot
        """
        return self._cells[ind]

    def __setitem__(self, ind, value):
        """
        :param ind: int
        :param value: any
        :return: None
        -------------
        Change value on ind-th slot
        """
        self._cells[ind] = value


class Board:
    """
    Represent Board
    """
    EMPTY = None
    BLUE = 1
    RED = 0

    def __init__(self):
        """
        Initialize board object
        """
        self._squares = TripleArray("array")

    def __getitem__(self, ind):
        """
        :param ind: int
        :return: any
        ------------
        Return item on ind-th position
        """
        return self._squares[ind[0]][ind[1]]

    def __setitem__(self, ind, value):
        """
        :param ind: int
        :param value: any
        :return: None
        -------------
        Change value on ind-th slot
        """
        self._squares[ind[0]][ind[1]] = value

    def is_free(self, ind):
        """
        :param ind: int
        :return: bool
        -------------
        Check whether slot on ind-th position is empty or not
        """
        return self[ind] is None

    def free_cells(self):
        """
        :return: list of tuples
        -----------------------
        Return list of positions of all free slots
        """
        are_free = []
        for row in range(SIZE):
            for col in range(SIZE):
                ind = (row, col)
                if self.is_free(ind):
                    are_free.append(ind)
        return are_free

    def __str__(self):
        """
        :return: str
        ------------
        Return string representation of object
        """
        smb_dict = {self.EMPTY: "\u3000",
                    self.BLUE: "\u2A09",
                    self.RED: "\u25EF"}
        str_ = "\n".join(["|" + "|".join([smb_dict[self[row, col]] for col in range(SIZE)]) + "|"
                          for row in range(SIZE)])
        return str_

    def is_over(self):
        """
        :return: tuple
        --------------
        Return whether game is over (first element of the tuple)
        and who has won the game (second element of the tuple)
        """
        if not self.free_cells():
            return True, None
        lst = [(0, 0), (0, 0), (0, 0), (0, 0), (0, 0), (0, 0), (0, 0), (0, 0)]
        score = lambda ind_1, ind_2: (lst[ind_2][0] + 1 if self[ind_1] == lst[ind_2][1]
                                      else 1, self[ind_1])
        for row in range(SIZE):
            for col in range(SIZE):
                ind = (row, col)
                if not self.is_free(ind):
                    lst[row] = score(ind, row)
                    lst[col+3] = score(ind, col+3)
                    if col == row:
                        lst[2*SIZE] = score(ind, 2*SIZE)
                    if row == (SIZE-1) - row:
                        lst[2*SIZE + 1] = score(ind, 2*SIZE + 1)
        res = ([(True, elm[1]) for elm in lst if SIZE in elm] or [(False, None)])[0]
        return res

    def copy(self):
        """
        :return: Board
        --------------
        Return copy of board object
        """
        board = Board()
        for row in range(SIZE):
            for col in range(SIZE):
                board[(row, col)] = self[(row, col)]
        return board

    def value(self):
        """
        :return: int
        Return importance of the game
        the higher is value the bigger is chance to win in the whole game
        """
        val = self.is_over()[0]
        return -1*(val == 1) or 1*(val == 0) or 0
